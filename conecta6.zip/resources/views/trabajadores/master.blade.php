@include('trabajadores.header')
  @yield('content')
@include('trabajadores.footer')
