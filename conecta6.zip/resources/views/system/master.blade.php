@include('system.header')
  @yield('content')
@include('system.footer')