@include('admin.header')
  @yield('content')
@include('admin.footer')
